package com.example.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Button;
import android.widget.ToggleButton;
import android.view.View;
import android.view.ViewGroup;

import java.util.*;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.FirebaseApp;
import android.os.Vibrator;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Vibrator v = (Vibrator) getSystemService(this.VIBRATOR_SERVICE);
        v.vibrate(2000);
        FirebaseApp.initializeApp(this);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("parents");
        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                HashMap<String, String> data = (HashMap<String, String>)dataSnapshot.getValue();

                String value = data.toString();
                //write(value);
                v.vibrate(500);
                Map.Entry<String,String> dataList[] = ((HashMap<String, String>)data).entrySet().toArray(new Map.Entry[data.size()]);
                write(Arrays.toString(((HashMap<String, String>)data).entrySet().toArray()));

                //Making button list

                //LinearLayout layout = (LinearLayout) findViewById(R.id.layout);
                TableLayout table = (TableLayout) findViewById(R.id.table);

                for(int i = 0; i<dataList.length; i++) {
                    TableRow tr = new TableRow(getApplicationContext());
                    tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

                    ToggleButton btnTag = new ToggleButton(getApplicationContext());
                    btnTag.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                    String btnText = dataList[i].getKey();
                    btnTag.setText(btnText);
                    btnTag.setTextOff(btnText);
                    btnTag.setTextOn(btnText);
                    tr.addView(btnTag);

                    TextView txtView = new TextView(getApplicationContext());
                    txtView.setText("This person is in the parking lot");
                    txtView.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                    tr.addView(txtView);
                    table.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));
                }

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                write("Well shucks mate");
            }
        });
    }



    boolean toggle = true;
    public void write(String text){
        TextView mainText = (TextView)findViewById(R.id.mainText);
        mainText.setText(text);
    }


    public void worldEnder(View view) {
        TextView mainText = (TextView)findViewById(R.id.mainText);
        if(toggle) {
            mainText.setText("RIP World 2K19");
        }
        else{
            mainText.setText("Why did you press the button again?");
        }
        toggle = !toggle;
    }
}

