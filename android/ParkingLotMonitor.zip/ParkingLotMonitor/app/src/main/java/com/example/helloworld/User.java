package com.example.helloworld;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class User {

    public String plates;
    public boolean inParkingLot;

    public User() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public User(String plates) {
        this.plates = plates;
        this.inParkingLot = false;
    }

}
