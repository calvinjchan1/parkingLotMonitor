package com.example.helloworld;

import android.util.Log;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.CompoundButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Button;
import android.widget.ToggleButton;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.Color;
import android.widget.Toast;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.app.Notification;
import android.os.PowerManager;

import java.util.*;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.FirebaseApp;
import android.os.Vibrator;



public class MainActivity extends AppCompatActivity {

    Map <String, Boolean> oldData = new HashMap<String, Boolean>();
    protected PowerManager.WakeLock mWakeLock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final PowerManager pm = (PowerManager) getSystemService(getApplicationContext().POWER_SERVICE);
        this.mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "parkingLotMonitor:MyTag");
        this.mWakeLock.acquire();

        final Map <String, Boolean> trackingMap = new HashMap<String, Boolean>();


        //Vibrator
        final Vibrator v = (Vibrator) getSystemService(this.VIBRATOR_SERVICE);
        //v.vibrate(2000);

        //firebase
        FirebaseApp.initializeApp(this);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("parents");
        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                HashMap<String, Boolean> data = (HashMap<String, Boolean>)dataSnapshot.getValue();

                String value = data.toString();
                //write(value);
                Map.Entry<String,Boolean> dataList[] = ((HashMap<String, Boolean>)data).entrySet().toArray(new Map.Entry[data.size()]);
                Map.Entry<String,Boolean> tempList[] = new Map.Entry[data.size()];
                //Sort List
                for(int i = 0; i<dataList.length; i++){
                    for(int j = 0; j<tempList.length; j++){
                        if(tempList[j] == null){
                            tempList[j] = dataList[i];
                            break;
                        }
                        else if(dataList[i].getKey().compareToIgnoreCase(tempList[j].getKey())<0)
                        {
                            //Insert into temp list
                            int insertSpot = j;
                            Map.Entry<String,Boolean> superTempList[] = new Map.Entry[data.size()];
                            for(int k = 0; k<insertSpot; k++)
                            {
                                superTempList[k] = tempList[k];
                            }
                            superTempList[insertSpot] = dataList[i];
                            for(int k = insertSpot+1; k<tempList.length; k++)
                            {
                                superTempList[k] = tempList[k-1];
                            }
                            tempList = Arrays.copyOf(superTempList, superTempList.length);
                            //Log.d("5256", ":C" + Arrays.toString(tempList));
                            break;
                        }
                    }
                }
                Log.d("5256", Arrays.toString(tempList));
                dataList = Arrays.copyOf(tempList, tempList.length);

                //Making button list

                //LinearLayout layout = (LinearLayout) findViewById(R.id.layout);
                TableLayout table = (TableLayout) findViewById(R.id.table);
                table.removeAllViews(); //Clear buttons so we don't get infinite buttons

                for(int i = 0; i<dataList.length; i++) {
                    //Create table row
                    TableRow tr = new TableRow(getApplicationContext());
                    tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

                    //Create toggle button
                    ToggleButton btnTag = new ToggleButton(getApplicationContext());
                    btnTag.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                    String btnText = dataList[i].getKey();
                    //Make sure that if the button was pressed before it stays pressed
                    if(trackingMap.containsKey(btnText)){
                        if(trackingMap.get(btnText)){
                            btnTag.setChecked(true);
                            //Vibrate if we are tracking and parent enters the lot
                            if(dataList[i].getValue()){
                                if(!(oldData.containsKey(dataList[i].getKey())&&oldData.get(dataList[i].getKey()))){
                                    //Send notification
                                    v.vibrate(2000);
                                    //Create notification channel
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        String description = "This is a notification channel";
                                        int importance = NotificationManager.IMPORTANCE_DEFAULT;
                                        NotificationChannel channel = new NotificationChannel("parkingLotMonitor", "Your Parent is in the parking lot!", importance);
                                        channel.setDescription(description);
                                        // Register the channel with the system; you can't change the importance
                                        // or other notification behaviors after this
                                        NotificationManager notificationManager = getSystemService(NotificationManager.class);
                                        notificationManager.createNotificationChannel(channel);
                                    }
                                    NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
                                    NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(getApplicationContext(), "parkingLotMonitor");
                                    mBuilder.setAutoCancel(true)
                                            .setDefaults(Notification.DEFAULT_ALL)
                                            .setWhen(System.currentTimeMillis())
                                            .setSmallIcon(R.mipmap.ic_launcher)
                                            .setTicker("ParkingLotMonitor")
                                            //.setPriority(Notification.PRIORITY_MAX)
                                            .setContentTitle("Your parent is in the parking lot!")
                                            .setContentText("Come get picked up!")
                                            .setContentInfo("Information");
                                    notificationManager.notify(1, mBuilder.build());
                                }
                            }
                        }
                    }
                    btnTag.setText(btnText);
                    btnTag.setTextOff(btnText);
                    btnTag.setTextOn(btnText);
                    //Toggle button behavior
                    btnTag.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            //Update the tracking map so we know which buttons are pressed
                            if(isChecked){
                                trackingMap.put(buttonView.getText().toString(), true);
                                //Toast.makeText(MainActivity.this, buttonView.getText().toString(), Toast.LENGTH_SHORT).show();
                            }
                            else {
                                trackingMap.put(buttonView.getText().toString(), false);
                            }
                        }

                    });
                    tr.addView(btnTag);

                    //Create text
                    String text;
                    TextView txtView = new TextView(getApplicationContext());
                    //write(dataList[i].getValue());
                    if(dataList[i].getValue()){
                        text = "This parent is in the parking lot";
                        txtView.setBackgroundColor(Color.parseColor("#EEffEE"));
                    }
                    else{
                        text = "This parent is not in the parking lot";
                        txtView.setBackgroundColor(Color.parseColor("#ffEEEE"));
                    }
                    txtView.setText(text);
                    txtView.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.FILL_PARENT));
                    tr.addView(txtView);
                    table.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.FILL_PARENT));
                }

                oldData = data;

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                write("Well shucks mate");
            }
        });
    }

    @Override
    public void onDestroy() {
        this.mWakeLock.release();
        super.onDestroy();
    }

    public void write(String text){
        TextView mainText = (TextView)findViewById(R.id.mainText);
        mainText.setText(text);
    }

}

