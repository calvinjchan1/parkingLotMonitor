package com.example.helloworld;

import android.text.InputType;
import android.widget.EditText;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.util.Log;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.CompoundButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Button;
import android.widget.ToggleButton;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.Color;
import android.widget.Toast;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.app.Notification;
import android.os.PowerManager;

import java.util.*;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.firebase.ui.auth.IdpResponse;
import com.firebase.ui.auth.AuthUI;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.FirebaseApp;
import android.os.Vibrator;



public class MainActivity extends AppCompatActivity {

    Map <String, Boolean> oldData = new HashMap<String, Boolean>();
    protected PowerManager.WakeLock mWakeLock;
    final int RC_SIGN_IN = 5;
    private DatabaseReference myRef;
    private DatabaseReference firebaseRef;
    private String lptext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //firebase
        FirebaseApp.initializeApp(this);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("parents");
        firebaseRef = database.getReference();

        List<AuthUI.IdpConfig> providers = Arrays.asList(
                new AuthUI.IdpConfig.EmailBuilder().build());
        // Create and launch sign-in intent
        startActivityForResult(
                AuthUI.getInstance()
                        .createSignInIntentBuilder()
                        .setAvailableProviders(providers)
                        .build(),
                RC_SIGN_IN);




        //Old app
        setContentView(R.layout.activity_main);

        final PowerManager pm = (PowerManager) getSystemService(getApplicationContext().POWER_SERVICE);
        this.mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "parkingLotMonitor:MyTag");
        this.mWakeLock.acquire();

        final Map <String, Boolean> trackingMap = new HashMap<String, Boolean>();


        //Vibrator
        final Vibrator v = (Vibrator) getSystemService(this.VIBRATOR_SERVICE);
        //v.vibrate(2000);

        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                HashMap<String, Boolean> data = (HashMap<String, Boolean>)dataSnapshot.getValue();

                String value = data.toString();
                //write(value);
                Map.Entry<String,Boolean> dataList[] = ((HashMap<String, Boolean>)data).entrySet().toArray(new Map.Entry[data.size()]);
                Map.Entry<String,Boolean> tempList[] = new Map.Entry[data.size()];
                //Sort List
                for(int i = 0; i<dataList.length; i++){
                    for(int j = 0; j<tempList.length; j++){
                        if(tempList[j] == null){
                            tempList[j] = dataList[i];
                            break;
                        }
                        else if(dataList[i].getKey().compareToIgnoreCase(tempList[j].getKey())<0)
                        {
                            //Insert into temp list
                            int insertSpot = j;
                            Map.Entry<String,Boolean> superTempList[] = new Map.Entry[data.size()];
                            for(int k = 0; k<insertSpot; k++)
                            {
                                superTempList[k] = tempList[k];
                            }
                            superTempList[insertSpot] = dataList[i];
                            for(int k = insertSpot+1; k<tempList.length; k++)
                            {
                                superTempList[k] = tempList[k-1];
                            }
                            tempList = Arrays.copyOf(superTempList, superTempList.length);
                            //Log.d("5256", ":C" + Arrays.toString(tempList));
                            break;
                        }
                    }
                }
                Log.d("5256", Arrays.toString(tempList));
                dataList = Arrays.copyOf(tempList, tempList.length);

                //Making button list

                //LinearLayout layout = (LinearLayout) findViewById(R.id.layout);
                TableLayout table = (TableLayout) findViewById(R.id.table);
                table.removeAllViews(); //Clear buttons so we don't get infinite buttons

                for(int i = 0; i<dataList.length; i++) {
                    //Create table row
                    TableRow tr = new TableRow(getApplicationContext());
                    tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

                    //Create toggle button
                    ToggleButton btnTag = new ToggleButton(getApplicationContext());
                    btnTag.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                    String btnText = dataList[i].getKey();
                    //Make sure that if the button was pressed before it stays pressed
                    if(trackingMap.containsKey(btnText)){
                        if(trackingMap.get(btnText)){
                            btnTag.setChecked(true);
                            //Vibrate if we are tracking and parent enters the lot
                            if(dataList[i].getValue()){
                                if(!(oldData.containsKey(dataList[i].getKey())&&oldData.get(dataList[i].getKey()))){
                                    //Send notification
                                    v.vibrate(2000);
                                    //Create notification channel
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        String description = "This is a notification channel";
                                        int importance = NotificationManager.IMPORTANCE_DEFAULT;
                                        NotificationChannel channel = new NotificationChannel("parkingLotMonitor", "Your Parent is in the parking lot!", importance);
                                        channel.setDescription(description);
                                        // Register the channel with the system; you can't change the importance
                                        // or other notification behaviors after this
                                        NotificationManager notificationManager = getSystemService(NotificationManager.class);
                                        notificationManager.createNotificationChannel(channel);
                                    }
                                    NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
                                    NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(getApplicationContext(), "parkingLotMonitor");
                                    mBuilder.setAutoCancel(true)
                                            .setDefaults(Notification.DEFAULT_ALL)
                                            .setWhen(System.currentTimeMillis())
                                            .setSmallIcon(R.mipmap.ic_launcher)
                                            .setTicker("ParkingLotMonitor")
                                            //.setPriority(Notification.PRIORITY_MAX)
                                            .setContentTitle("Your parent is in the parking lot!")
                                            .setContentText("Come get picked up!")
                                            .setContentInfo("Information");
                                    notificationManager.notify(1, mBuilder.build());
                                }
                            }
                        }
                    }
                    btnTag.setText(btnText);
                    btnTag.setTextOff(btnText);
                    btnTag.setTextOn(btnText);
                    //Toggle button behavior
                    btnTag.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            //Update the tracking map so we know which buttons are pressed
                            if(isChecked){
                                trackingMap.put(buttonView.getText().toString(), true);
                                //Toast.makeText(MainActivity.this, buttonView.getText().toString(), Toast.LENGTH_SHORT).show();
                            }
                            else {
                                trackingMap.put(buttonView.getText().toString(), false);
                            }
                        }

                    });
                    tr.addView(btnTag);

                    //Create text
                    String text;
                    TextView txtView = new TextView(getApplicationContext());
                    //write(dataList[i].getValue());
                    if(dataList[i].getValue()){
                        text = "This parent is in the parking lot";
                        txtView.setBackgroundColor(Color.parseColor("#EEffEE"));
                    }
                    else{
                        text = "This parent is not in the parking lot";
                        txtView.setBackgroundColor(Color.parseColor("#ffEEEE"));
                    }
                    txtView.setText(text);
                    txtView.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.FILL_PARENT));
                    tr.addView(txtView);
                    table.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.FILL_PARENT));
                }

                oldData = data;

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                //write("Well shucks mate");
            }
        });
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            IdpResponse response = IdpResponse.fromResultIntent(data);

            if (resultCode == RESULT_OK) {
                // Successfully signed in
                final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                //final User myUser = new User("52345, asdf, 34");

                //Check if child exists
                DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("users");
                rootRef.child(user.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            //Do if we already have an data set up
                        }
                        else
                        {
                            //Do otherwise
                            newUserData(user.getUid());
                        }
                    }
                    public void onCancelled(DatabaseError error){

                    }
                });
                write("Sign In SUCCESFULL!!");
                // ...
            } else {
                // Sign in failed. If response is null the user canceled the
                // sign-in flow using the back button. Otherwise check
                // response.getError().getErrorCode() and handle the error.
                // ...
                write("EVERYTHING IS TERRIBLE FOREVER");
            }
        }
    }

    public void newUserData(final String uid){
        //Get the license plate from the user
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter your license plates");
        builder.setMessage("Enter the license plate each car you want tracked, separated by commas. Please do NOT include spaces or dashes, and please DO capitalize all letters");

        // Set up the input
        final EditText input = new EditText(this);
        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                lptext = input.getText().toString();
                final User myUser = new User(lptext);
                write(lptext);
                firebaseRef.child("users").child(uid).setValue(myUser);
            }
        });
        builder.show();

    }

    @Override
    public void onDestroy() {
        this.mWakeLock.release();
        super.onDestroy();
    }

    public void write(String text){
        TextView mainText = (TextView)findViewById(R.id.mainText);
        mainText.setText(text);
    }

}

